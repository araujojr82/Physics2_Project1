#pragma once

namespace nPhysics
{
	enum eShapeType
	{
		SHAPE_TYPE_PLANE,
		SHAPE_TYPE_SPHERE
	};
}
#include "Utilities.h"
#include <cstdlib>	// RAND_MAX

//// Inspired by: https://stackoverflow.com/questions/686353/c-random-float-number-generation
//
//double getRandInRange( double min, double max )
//{
//
//	double value = min + static_cast <double> (rand()) / ( static_cast <double> (RAND_MAX/(max-min)));
//	return value;
//}
